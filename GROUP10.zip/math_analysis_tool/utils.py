# utils.py
# This module contains various utility functions, including robust input validation,
# polynomial string parsing helpers, and a basic ASCII plotting utility.

import re
import math # For math.factorial

class InputValidator:
    """
    Provides static methods for validating various types of user input.
    """

    @staticmethod
    def get_valid_int_input(prompt, min_val=None, max_val=None):
        """
        Prompts the user for an integer input and validates its format and optional range.

        Args:
            prompt (str): The message to display to the user.
            min_val (int, optional): The minimum allowed integer value.
            max_val (int, optional): The maximum allowed integer value.

        Returns:
            int: The validated integer input.
        """
        while True:
            try:
                value = int(input(prompt).strip())
                if min_val is not None and value < min_val:
                    print(f"[ERROR] Value must be at least {min_val}.")
                elif max_val is not None and value > max_val:
                    print(f"[ERROR] Value must be at most {max_val}.")
                else:
                    return value
            except ValueError:
                print("[ERROR] Invalid input. Please enter a whole number.")
            except Exception as e:
                print(f"[ERROR] An unexpected error occurred: {e}. Please try again.")
            print("Please try again.")

    @staticmethod
    def get_valid_float_input(prompt, min_val=None, max_val=None):
        """
        Prompts the user for a floating-point number input and validates its format and optional range.

        Args:
            prompt (str): The message to display to the user.
            min_val (float, optional): The minimum allowed float value.
            max_val (float, optional): The maximum allowed float value.

        Returns:
            float: The validated float input.
        """
        while True:
            try:
                value = float(input(prompt).strip())
                if min_val is not None and value < min_val:
                    print(f"[ERROR] Value must be at least {min_val}.")
                elif max_val is not None and value > max_val:
                    print(f"[ERROR] Value must be at most {max_val}.")
                else:
                    return value
            except ValueError:
                print("[ERROR] Invalid input. Please enter a number.")
            except Exception as e:
                print(f"[ERROR] An unexpected error occurred: {e}. Please try again.")
            print("Please try again.")

    @staticmethod
    def get_yes_no_input(prompt):
        """
        Prompts the user for a yes/no answer and returns a boolean.

        Args:
            prompt (str): The message to display to the user.

        Returns:
            bool: True for 'yes' or 'y', False for 'no' or 'n'.
        """
        while True:
            response = input(f"{prompt} (yes/no): ").strip().lower()
            if response in ['yes', 'y']:
                return True
            elif response in ['no', 'n']:
                return False
            else:
                print("[ERROR] Invalid input. Please enter 'yes' or 'no'.")

def parse_polynomial_string(func_str):
    """
    Parses a string representation of a polynomial into a dictionary of coefficients.
    Supports terms like '3*x^2', 'x^3', '2*x', 'x', '5', '-x', '-4*x^2'.

    Args:
        func_str (str): The polynomial string.

    Returns:
        dict: A dictionary where keys are exponents (int) and values are coefficients (float).

    Raises:
        ValueError: If the string format is invalid.
    """
    coefficients = {}
    # Normalize the string: replace ' - ' with ' + -' to simplify splitting by '+'
    # Also ensure 'x' without coefficient is treated as '1*x'
    # And 'x^n' without coefficient is treated as '1*x^n'
    normalized_str = func_str.replace("-", "+-").replace(" ", "") # Replace spaces for easier regex

    # Handle cases like 'x' and '-x' by making coefficient explicit
    normalized_str = re.sub(r'(?<!\d|\*)[x]', r'1*x', normalized_str)
    normalized_str = re.sub(r'-\*x', r'-1*x', normalized_str) # Fix for -*x becoming -1*x
    normalized_str = re.sub(r'(?<!\d|\*)[x]\^', r'1*x^', normalized_str) # Fix for x^n becoming 1*x^n
    normalized_str = re.sub(r'-\*x\^', r'-1*x^', normalized_str) # Fix for -*x^n becoming -1*x^n

    # Split by '+' to get individual terms
    terms = [term for term in normalized_str.split("+") if term]

    if not terms:
        raise ValueError("Invalid polynomial format: No terms found.")

    for term in terms:
        if not term: continue # Skip empty strings from splitting

        # Regex to capture coefficient, 'x' (optional), and exponent (optional)
        # Group 1: coefficient (e.g., "3", "-2", "1")
        # Group 2: 'x' (optional)
        # Group 3: exponent (e.g., "2", "3")
        match = re.match(r"([-+]?\d*\.?\d*)(?:(\*x)(?:\^(\d+))?)?", term)

        if not match:
            # Handle constant terms like "5" or "-7"
            if re.match(r"[-+]?\d*\.?\d+$", term):
                coeff = float(term)
                coefficients[0] = coefficients.get(0, 0.0) + coeff
                continue
            else:
                raise ValueError(f"Invalid term in polynomial: '{term}'")

        coeff_str = match.group(1)
        has_x = match.group(2)
        exp_str = match.group(3)

        coeff = 1.0 if not coeff_str else float(coeff_str) # Default coeff to 1 if not specified (e.g., 'x^2')

        if has_x:
            exponent = int(exp_str) if exp_str else 1 # Default exponent to 1 if 'x' but no '^n'
        else:
            exponent = 0 # Constant term (e.g., "5")

        coefficients[exponent] = coefficients.get(exponent, 0.0) + coeff

    return coefficients

def ascii_plotter(points, x_min, x_max, y_min, y_max, width=60, height=20):
    """
    Generates a basic ASCII plot for a set of (x, y) points.

    Args:
        points (list): A list of (x, y) tuples to plot.
        x_min (float): Minimum x-value for the plot range.
        x_max (float): Maximum x-value for the plot range.
        y_min (float): Minimum y-value for the plot range.
        y_max (float): Maximum y-value for the plot range.
        width (int): Width of the plot grid (characters).
        height (int): Height of the plot grid (characters).

    Returns:
        list: A list of strings, each representing a line of the ASCII plot.
    """
    plot_grid = [[' ' for _ in range(width)] for _ in range(height)]

    # Draw Y-axis
    for y in range(height):
        plot_grid[y][0] = '|'
    # Draw X-axis
    for x in range(width):
        plot_grid[height - 1][x] = '-'
    # Origin
    plot_grid[height - 1][0] = '+'

    # Scale factors
    x_scale = (width - 1) / (x_max - x_min) if (x_max - x_min) > 0 else 1
    y_scale = (height - 1) / (y_max - y_min) if (y_max - y_min) > 0 else 1

    # Plot points
    for x_val, y_val in points:
        # Map x, y to grid coordinates
        grid_x = int((x_val - x_min) * x_scale)
        grid_y = int((y_val - y_min) * y_scale)

        # Invert y-axis for console display (top-left is 0,0)
        grid_y = height - 1 - grid_y

        # Ensure coordinates are within bounds
        if 0 <= grid_x < width and 0 <= grid_y < height:
            plot_grid[grid_y][grid_x] = '*'

    # Add labels (very basic)
    plot_lines = []
    for i, row in enumerate(plot_grid):
        line = "".join(row)
        if i == 0: # Top Y label
            line += f" Y={y_max:.1f}"
        elif i == height - 1: # Bottom X label
            line += f" X={x_max:.1f}"
        elif i == height // 2: # Middle Y label
            line += f" Y={(y_min + y_max) / 2:.1f}"
        plot_lines.append(line)
    
    # Add X-axis label at the bottom
    plot_lines.append(f"X={x_min:.1f}" + " " * (width - len(f"X={x_min:.1f}") - len(f"X={x_max:.1f}")) + f"X={x_max:.1f}")

    return plot_lines
