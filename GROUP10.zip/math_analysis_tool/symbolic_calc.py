# symbolic_calc.py
# This module implements the symbolic calculus engine for polynomial functions.
# It handles differentiation, integration, series expansion, and limit calculation.

import math
import re
from utils import parse_polynomial_string # Import the parsing utility

class Polynomial:
    """
    Represents a polynomial function.
    Stores coefficients by their corresponding exponent in a dictionary.
    e.g., 3*x^2 + 2*x - 5  ->  {2: 3.0, 1: 2.0, 0: -5.0}
    """
    def __init__(self, func_str):
        """
        Initializes a Polynomial object by parsing a function string.

        Args:
            func_str (str): A string representation of a polynomial (e.g., "3*x^2 + 2*x - 5").
                            Supports only 'x' as variable, integer exponents, and basic arithmetic.

        Raises:
            ValueError: If the function string is not a valid polynomial.
        """
        self.coefficients = {} # {exponent: coefficient}
        if not func_str:
            raise ValueError("Polynomial function string cannot be empty.")

        # Use the utility function to parse the string
        self.coefficients = parse_polynomial_string(func_str)

        # Remove terms with zero coefficients to keep it clean
        self.coefficients = {exp: coeff for exp, coeff in self.coefficients.items() if coeff != 0}

        # If after parsing and cleaning, no coefficients are left (e.g., input was "0"),
        # represent it as a constant zero polynomial.
        if not self.coefficients:
            self.coefficients[0] = 0.0

    def to_string(self):
        """
        Converts the polynomial back into a human-readable string.

        Returns:
            str: String representation of the polynomial.
        """
        terms = []
        # Sort exponents in descending order for standard polynomial representation
        sorted_exponents = sorted(self.coefficients.keys(), reverse=True)

        for exp in sorted_exponents:
            coeff = self.coefficients[exp]

            if coeff == 0:
                continue # Skip zero terms

            # Determine the sign for the term
            sign = "+" if coeff > 0 else "-"
            if not terms and sign == "+": # Don't add '+' for the very first positive term
                sign = ""
            
            abs_coeff = abs(coeff)

            if exp == 0: # Constant term
                terms.append(f"{sign}{abs_coeff}")
            elif exp == 1: # x term (e.g., 2x, -x)
                if abs_coeff == 1:
                    terms.append(f"{sign}x")
                else:
                    terms.append(f"{sign}{abs_coeff}*x")
            else: # x^n term
                if abs_coeff == 1:
                    terms.append(f"{sign}x^{exp}")
                else:
                    terms.append(f"{sign}{abs_coeff}*x^{exp}")

        if not terms:
            return "0" # If all terms are zero or input was invalid

        # Join terms, removing leading '+' if present
        result = "".join(terms).strip()
        if result.startswith("+"):
            result = result[1:] # Remove leading '+'
        return result if result else "0" # Return "0" if result is empty string (e.g., from "0")

    def evaluate(self, x_val):
        """
        Evaluates the polynomial at a given x value.

        Args:
            x_val (float): The value of x to substitute into the polynomial.

        Returns:
            float: The result of the polynomial evaluation.
        """
        result = 0.0
        for exp, coeff in self.coefficients.items():
            result += coeff * (x_val ** exp)
        return result

# --- Symbolic Calculus Functions ---

def differentiate_polynomial(poly_obj):
    """
    Performs symbolic differentiation on a Polynomial object.

    Args:
        poly_obj (Polynomial): The polynomial to differentiate.

    Returns:
        Polynomial: A new Polynomial object representing the derivative.
    """
    new_coefficients = {}
    for exp, coeff in poly_obj.coefficients.items():
        if exp > 0: # Power rule: d/dx(ax^n) = anx^(n-1)
            new_coefficients[exp - 1] = coeff * exp
        # If exp is 0 (constant term), its derivative is 0, so we don't add it.

    # If the derivative is 0 (e.g., differentiating a constant), ensure it's represented as "0"
    if not new_coefficients:
        return Polynomial("0")
    
    # Create a dummy string to initialize the new Polynomial object.
    # This is a bit of a workaround because Polynomial's __init__ expects a string.
    # A more robust Polynomial class might have an __init__ that takes a dict directly.
    # For now, we'll create a string from the new coefficients.
    temp_poly_str = ""
    sorted_exps = sorted(new_coefficients.keys(), reverse=True)
    for exp in sorted_exps:
        c = new_coefficients[exp]
        if c == 0: continue
        
        term = ""
        if exp == 0:
            term = str(c)
        elif exp == 1:
            term = f"{c}*x"
        else:
            term = f"{c}*x^{exp}"
        
        if temp_poly_str and c > 0:
            temp_poly_str += "+"
        temp_poly_str += term

    return Polynomial(temp_poly_str if temp_poly_str else "0")


def integrate_polynomial(poly_obj):
    """
    Performs symbolic indefinite integration on a Polynomial object.

    Args:
        poly_obj (Polynomial): The polynomial to integrate.

    Returns:
        Polynomial: A new Polynomial object representing the indefinite integral (without + C).
    """
    new_coefficients = {}
    for exp, coeff in poly_obj.coefficients.items():
        # Power rule: ∫ax^n dx = (a/(n+1))x^(n+1)
        new_coefficients[exp + 1] = coeff / (exp + 1)

    # If the integral is 0 (e.g., integrating 0), ensure it's represented as "0"
    if not new_coefficients:
        return Polynomial("0")

    # Similar workaround as in differentiate_polynomial to initialize the new Polynomial
    temp_poly_str = ""
    sorted_exps = sorted(new_coefficients.keys(), reverse=True)
    for exp in sorted_exps:
        c = new_coefficients[exp]
        if c == 0: continue
        
        term = ""
        if exp == 0: # This case should ideally not happen for integration of non-zero poly
            term = str(c)
        elif exp == 1:
            term = f"{c}*x"
        else:
            term = f"{c}*x^{exp}"
        
        if temp_poly_str and c > 0:
            temp_poly_str += "+"
        temp_poly_str += term
    
    return Polynomial(temp_poly_str if temp_poly_str else "0")

def calculate_limit_lhopital(numerator_str, denominator_str, point):
    """
    Calculates the limit of a ratio of polynomial functions using L'Hôpital's Rule.

    Args:
        numerator_str (str): String representation of the numerator polynomial.
        denominator_str (str): String representation of the denominator polynomial.
        point (float or float('inf')): The value x approaches.

    Returns:
        tuple: (limit_value, steps_taken)
               limit_value (float or str): The calculated limit, or "Undefined" / "Infinity".
               steps_taken (list): A list of strings detailing the steps.

    Raises:
        ValueError: If polynomial parsing fails.
    """
    steps = []
    try:
        num_poly = Polynomial(numerator_str)
        den_poly = Polynomial(denominator_str)
    except ValueError as e:
        raise ValueError(f"Error parsing functions: {e}")

    # Handle division by zero for initial evaluation
    if den_poly.evaluate(point) == 0 and num_poly.evaluate(point) != 0:
        return "Infinity" if num_poly.evaluate(point) > 0 else "-Infinity", ["Denominator is zero, numerator is non-zero."]

    # Direct substitution if denominator is not zero
    if den_poly.evaluate(point) != 0:
        limit_val = num_poly.evaluate(point) / den_poly.evaluate(point)
        steps.append(f"Direct substitution: f({point}) = {num_poly.evaluate(point)}, g({point}) = {den_poly.evaluate(point)}")
        steps.append(f"Limit = {limit_val}")
        return limit_val, steps

    # Check for indeterminate forms (0/0 or inf/inf)
    num_at_point = num_poly.evaluate(point)
    den_at_point = den_poly.evaluate(point)

    is_indeterminate = False
    if (abs(num_at_point) < 1e-9 and abs(den_at_point) < 1e-9) or \
       (point == float('inf') and (num_at_point == float('inf') or num_at_point == float('-inf')) and \
                                  (den_at_point == float('inf') or den_at_point == float('-inf'))):
        is_indeterminate = True

    if not is_indeterminate:
        if den_at_point == 0:
            return "Undefined (Division by Zero)" if num_at_point == 0 else "Infinity", ["Not an indeterminate form, direct substitution leads to division by zero."]
        else:
            return num_at_point / den_at_point, ["Not an indeterminate form, direct substitution yields a finite value."]

    steps.append(f"Initial evaluation at x={point}: Numerator = {num_at_point}, Denominator = {den_at_point}")
    steps.append("Indeterminate form (0/0 or inf/inf) detected. Applying L'Hôpital's Rule.")

    # Apply L'Hôpital's Rule iteratively
    current_num = num_poly
    current_den = den_poly
    iteration = 0
    max_iterations = 10 # Prevent infinite loops for complex cases or errors

    while is_indeterminate and iteration < max_iterations:
        iteration += 1
        steps.append(f"\nIteration {iteration}:")
        steps.append(f"  Current Numerator: {current_num.to_string()}")
        steps.append(f"  Current Denominator: {current_den.to_string()}")

        # Differentiate both numerator and denominator
        deriv_num = differentiate_polynomial(current_num)
        deriv_den = differentiate_polynomial(current_den)

        steps.append(f"  Derivative of Numerator: {deriv_num.to_string()}")
        steps.append(f"  Derivative of Denominator: {deriv_den.to_string()}")

        # If derivative of denominator becomes zero and stays zero, or both are zero
        if deriv_den.to_string() == "0":
            if deriv_num.to_string() == "0":
                steps.append("  Both derivatives are zero. Limit may be undefined or requires more advanced analysis.")
                return "Undefined", steps # Cannot resolve further with L'Hopital's
            else:
                # Non-zero / Zero -> Infinity
                steps.append("  Denominator derivative is zero, numerator derivative is non-zero.")
                return "Infinity" if deriv_num.evaluate(point) > 0 else "-Infinity", steps

        current_num = deriv_num
        current_den = deriv_den

        num_at_point = current_num.evaluate(point)
        den_at_point = current_den.evaluate(point)

        steps.append(f"  Evaluate derivatives at x={point}: Numerator' = {num_at_point}, Denominator' = {den_at_point}")

        is_indeterminate = False
        if (abs(num_at_point) < 1e-9 and abs(den_at_point) < 1e-9) or \
           (point == float('inf') and (num_at_point == float('inf') or num_at_point == float('-inf')) and \
                                      (den_at_point == float('inf') or den_at_point == float('-inf'))):
            is_indeterminate = True

    if is_indeterminate:
        steps.append(f"\nMax iterations ({max_iterations}) reached or still in indeterminate form.")
        return "Could not determine (still indeterminate)", steps
    else:
        # Final evaluation
        if abs(den_at_point) < 1e-9: # Check if denominator is effectively zero
            if abs(num_at_point) < 1e-9:
                steps.append("Final form is 0/0, but max iterations reached or cannot resolve.")
                return "Undefined", steps
            else:
                steps.append("Final form is non-zero/0.")
                return "Infinity" if num_at_point > 0 else "-Infinity", steps
        else:
            limit_val = num_at_point / den_at_point
            steps.append(f"Final evaluation: {num_at_point} / {den_at_point} = {limit_val}")
            return limit_val, steps


def taylor_maclaurin_series(func_poly, center, order):
    """
    Calculates the Taylor (or Maclaurin if center=0) series expansion of a polynomial.

    Args:
        func_poly (Polynomial): The polynomial function to expand.
        center (float): The point 'a' around which to expand the series.
        order (int): The order 'n' of the expansion.

    Returns:
        tuple: (series_string, steps_list)
               series_string (str): The string representation of the series.
               steps_list (list): A list of strings detailing the steps.
    """
    steps = []
    series_terms = []
    current_poly = func_poly

    steps.append(f"Function: f(x) = {func_poly.to_string()}")
    steps.append(f"Center (a): {center}, Order (n): {order}")

    for k in range(order + 1):
        # Calculate the k-th derivative
        if k == 0:
            deriv_k = func_poly # 0th derivative is the function itself
            deriv_k_str = func_poly.to_string()
        else:
            deriv_k = differentiate_polynomial(current_poly)
            deriv_k_str = deriv_k.to_string()
            current_poly = deriv_k # Update for next differentiation

        # Evaluate the k-th derivative at the center point 'a'
        f_k_a = deriv_k.evaluate(center)
        
        # Calculate k!
        k_factorial = math.factorial(k)

        steps.append(f"\nStep {k}:")
        steps.append(f"  f^({k})(x) = {deriv_k_str}")
        steps.append(f"  f^({k})({center}) = {f_k_a}")
        steps.append(f"  {k}! = {k_factorial}")

        # Calculate the term for the series: (f^(k)(a) / k!) * (x - a)^k
        coeff_term = f_k_a / k_factorial

        if coeff_term == 0:
            steps.append(f"  Term is 0, skipping.")
            continue # Skip zero terms

        term_str = ""
        if k == 0:
            term_str = str(coeff_term)
        elif k == 1:
            if center == 0:
                term_str = f"{coeff_term}*x"
            else:
                term_str = f"{coeff_term}*(x - {center})"
        else:
            if center == 0:
                term_str = f"{coeff_term}*x^{k}"
            else:
                term_str = f"{coeff_term}*(x - {center})^{k}"
        
        series_terms.append(term_str)
        steps.append(f"  Term {k}: {term_str}")

    # Join terms with '+'
    series_string = " + ".join(series_terms)
    # Clean up redundant '+' signs if any
    series_string = series_string.replace(" + -", " - ")
    
    # If no terms, it's a 0 polynomial
    if not series_string:
        series_string = "0"

    return series_string, steps
