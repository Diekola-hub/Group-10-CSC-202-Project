# report_gen.py
# This module is responsible for formatting and generating comprehensive
# calculus analysis reports as text files.

import os
import datetime
from utils import ascii_plotter # Import the ASCII plotter utility

class ReportGenerator:
    """
    Generates comprehensive calculus reports based on analysis results.
    Formats various mathematical operations and saves them to a text file.
    """

    def __init__(self, output_dir="reports"):
        self.output_dir = output_dir
        # Ensure the output directory exists, create if not
        os.makedirs(self.output_dir, exist_ok=True)

    def generate_report(self, operation_type, input_function, result, steps=None, plot_data=None, file_name=None):
        """
        Generates a text report summarizing a calculus analysis.

        Args:
            operation_type (str): The type of calculus operation (e.g., "Symbolic Differentiation").
            input_function (str): The string representation of the input function(s).
            result (str): The final result of the operation.
            steps (list, optional): A list of strings detailing step-by-step explanations. Defaults to None.
            plot_data (dict, optional): Dictionary containing data for ASCII plotting.
                                        e.g., {"original": [(x,y),...], "derived": [(x,y),...]}
                                        or {"solution": [(x,y),...]}
                                        Defaults to None.
            file_name (str, optional): The desired name for the report file.
                                       If None, a timestamped name will be generated.

        Returns:
            str or None: The full path to the generated report file if successful,
                         None otherwise.
        """
        # Format all analysis results into a single string
        report_content = self._format_report(
            operation_type, input_function, result, steps, plot_data
        )

        # Determine the output file name
        if file_name is None:
            timestamp_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"{operation_type.lower().replace(' ', '_')}_report_{timestamp_str}.txt"

        file_path = os.path.join(self.output_dir, file_name)

        try:
            # Write the formatted report content to the file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(report_content)
            # print(f"[INFO] Report successfully generated: {file_path}") # Suppress this in report_gen, main.py prints it
            return file_path
        except IOError as e:
            print(f"[ERROR] Could not write report to {file_path}: {e}")
            return None
        except Exception as e:
            print(f"[ERROR] An unexpected error occurred during report generation: {e}")
            return None

    def _format_report(self, operation_type, input_function, result, steps, plot_data):
        """
        Internal method to format the analysis results into a structured string.

        Args:
            operation_type (str): The type of calculus operation.
            input_function (str): The input function(s) string.
            result (str): The final result.
            steps (list): Step-by-step explanations.
            plot_data (dict): Data for ASCII plotting.

        Returns:
            str: The formatted report content as a single string.
        """
        report_lines = []
        report_lines.append("=" * 60)
        report_lines.append(f"       MATHEMATICAL ANALYSIS REPORT - {operation_type.upper()}")
        report_lines.append("=" * 60)
        report_lines.append(f"Report Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

        # --- Operation Details ---
        report_lines.append(self._format_section("Operation Details", [
            f"Operation Type: {operation_type}",
            f"Input Function(s): {input_function}"
        ]))

        # --- Result ---
        report_lines.append(self._format_section("Result", [result]))

        # --- Step-by-Step Explanation ---
        if steps:
            report_lines.append(self._format_section("Step-by-Step Explanation", steps))
        else:
            report_lines.append(self._format_section("Step-by-Step Explanation", ["No detailed steps available for this operation."]))

        # --- ASCII Plot ---
        if plot_data:
            report_lines.append("\n--- ASCII Plot ---")
            report_lines.append("Note: This is a basic ASCII representation and may not be perfectly accurate for all functions.")
            
            all_points = []
            for key in plot_data:
                all_points.extend(plot_data[key])
            
            if all_points:
                # Determine plot ranges dynamically
                x_values = [p[0] for p in all_points]
                y_values = [p[1] for p in all_points]

                # Add some padding to ranges
                x_min = min(x_values) - 1 if x_values else -10
                x_max = max(x_values) + 1 if x_values else 10
                y_min = min(y_values) - 1 if y_values else -10
                y_max = max(y_values) + 1 if y_values else 10
                
                # Ensure a minimum range to avoid division by zero if all points are identical
                if x_max - x_min < 2: x_max = x_min + 2
                if y_max - y_min < 2: y_max = y_min + 2

                # Generate plot for each set of points
                plot_output_lines = []
                for label, points_list in plot_data.items():
                    plot_output_lines.append(f"Plot for {label.replace('_', ' ').title()}:")
                    plot_output_lines.extend(ascii_plotter(points_list, x_min, x_max, y_min, y_max, width=60, height=20))
                    plot_output_lines.append("\n") # Separator between plots if multiple

                report_lines.extend(plot_output_lines)
            else:
                report_lines.append("No plot data available.")
            report_lines.append("\n")
        else:
            report_lines.append(self._format_section("ASCII Plot", ["No plot generated for this operation."]))


        report_lines.append("=" * 60)
        report_lines.append("END OF REPORT")
        report_lines.append("=" * 60)

        return "\n".join(report_lines)

    def _format_section(self, title, content_lines):
        """Helper to format a section with a title and list of content lines."""
        section = [f"\n--- {title} ---"]
        section.extend([f"  {line}" for line in content_lines])
        section.append("") # Add a blank line for spacing
        return "\n".join(section)
