# numerical_solver.py
# This module provides numerical methods for solving mathematical problems,
# specifically first-order ordinary differential equations using Euler's method.

from symbolic_calc import Polynomial # Import Polynomial class for function evaluation

def solve_ode_euler(func_str, x0, y0, h, num_steps):
    """
    Numerically solves a first-order ordinary differential equation dy/dx = f(x)
    using Euler's method.

    Args:
        func_str (str): String representation of f(x) in dy/dx = f(x).
                        Must be a polynomial in 'x'.
        x0 (float): Initial value of x.
        y0 (float): Initial value of y.
        h (float): Step size.
        num_steps (int): Number of steps to approximate the solution.

    Returns:
        list: A list of tuples (x, y) representing the approximated solution points.

    Raises:
        ValueError: If func_str cannot be parsed as a polynomial.
    """
    try:
        # Parse f(x) into a Polynomial object
        f_x_poly = Polynomial(func_str)
    except ValueError as e:
        raise ValueError(f"Invalid function f(x) for ODE: {e}")

    solution_points = [(x0, y0)]
    current_x = x0
    current_y = y0

    for i in range(num_steps):
        # Calculate f(x_n, y_n). Since we only support f(x), y_n is not used in f_x_poly.evaluate.
        # If f(x,y) support were added, f_x_poly.evaluate would need to handle 'y' as well.
        f_val = f_x_poly.evaluate(current_x)

        # Euler's method formula: y_{n+1} = y_n + h * f(x_n, y_n)
        next_y = current_y + h * f_val
        next_x = current_x + h

        solution_points.append((next_x, next_y))

        current_x = next_x
        current_y = next_y

    return solution_points
