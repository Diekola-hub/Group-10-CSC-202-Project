# function_analysis.py
# This module provides basic analysis of function properties,
# specifically continuity and differentiability for polynomial functions.

from symbolic_calc import Polynomial, differentiate_polynomial # Import for function evaluation and derivative

def analyze_continuity_differentiability(func_str, point):
    """
    Analyzes the continuity and differentiability of a polynomial function at a given point.

    Args:
        func_str (str): String representation of the polynomial function.
        point (float): The point x0 at which to analyze.

    Returns:
        tuple: (analysis_result_str, steps_list)
               analysis_result_str (str): A summary string of the analysis.
               steps_list (list): A list of strings detailing the steps/reasoning.

    Raises:
        ValueError: If the function string cannot be parsed.
    """
    steps = []
    try:
        func_poly = Polynomial(func_str)
        deriv_poly = differentiate_polynomial(func_poly)
    except ValueError as e:
        raise ValueError(f"Invalid function input: {e}")

    steps.append(f"Function f(x) = {func_poly.to_string()}")
    steps.append(f"Analysis point x0 = {point}")

    # For polynomial functions, continuity and differentiability are straightforward.
    # Polynomials are continuous everywhere.
    # Polynomials are differentiable everywhere.

    steps.append("\n--- Continuity Analysis ---")
    steps.append("1. Polynomial functions are defined for all real numbers.")
    steps.append("2. The limit of a polynomial function as x approaches any point x0 is equal to f(x0).")
    steps.append("3. Therefore, polynomial functions are continuous at all points in their domain.")
    steps.append(f"Conclusion: f(x) = {func_poly.to_string()} is continuous at x = {point}.")

    steps.append("\n--- Differentiability Analysis ---")
    steps.append("1. The derivative of a polynomial function exists for all real numbers.")
    steps.append(f"2. The derivative f'(x) = {deriv_poly.to_string()}.")
    steps.append(f"3. Since f'(x) is also a polynomial, it is defined for all real numbers.")
    steps.append("4. A function is differentiable at a point if its derivative exists at that point.")
    steps.append(f"Conclusion: f(x) = {func_poly.to_string()} is differentiable at x = {point}.")

    result_str = (f"The function f(x) = {func_poly.to_string()} is both continuous and differentiable "
                  f"at x = {point}, as all polynomial functions are continuous and differentiable everywhere.")

    return result_str, steps

