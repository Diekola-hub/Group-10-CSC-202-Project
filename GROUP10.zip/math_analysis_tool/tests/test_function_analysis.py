# tests/test_function_analysis.py
# Unit tests for the function_analysis module, covering continuity and differentiability checks.

import unittest
import sys # For path manipulation if needed for imports
import os

# Add parent directory to path to allow importing modules from the main project
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from function_analysis import analyze_continuity_differentiability

class TestFunctionAnalysis(unittest.TestCase):
    """Tests the function analysis capabilities."""

    def test_analyze_continuity_differentiability_polynomial(self):
        # Test a simple polynomial function
        func_str = "x^2 + 2*x - 1"
        point = 3.0
        result_str, steps = analyze_continuity_differentiability(func_str, point)

        self.assertIn(f"The function f(x) = 1.0*x^2 + 2.0*x - 1.0 is both continuous and differentiable at x = {point}", result_str)
        self.assertIn("Polynomial functions are continuous at all points in their domain.", steps)
        self.assertIn("The derivative of a polynomial function exists for all real numbers.", steps)
        self.assertIn("f'(x) = 2.0*x + 2.0", steps) # Check for derivative string

    def test_analyze_continuity_differentiability_constant(self):
        # Test a constant function
        func_str = "5"
        point = -10.0
        result_str, steps = analyze_continuity_differentiability(func_str, point)

        self.assertIn(f"The function f(x) = 5.0 is both continuous and differentiable at x = {point}", result_str)
        self.assertIn("Polynomial functions are continuous at all points in their domain.", steps)
        self.assertIn("The derivative of a polynomial function exists for all real numbers.", steps)
        self.assertIn("f'(x) = 0", steps) # Derivative of a constant is 0

    def test_analyze_continuity_differentiability_linear(self):
        # Test a linear function
        func_str = "-3*x + 7"
        point = 0.0
        result_str, steps = analyze_continuity_differentiability(func_str, point)

        self.assertIn(f"The function f(x) = -3.0*x + 7.0 is both continuous and differentiable at x = {point}", result_str)
        self.assertIn("Polynomial functions are continuous at all points in their domain.", steps)
        self.assertIn("The derivative of a polynomial function exists for all real numbers.", steps)
        self.assertIn("f'(x) = -3.0", steps) # Derivative of -3x+7 is -3

    def test_analyze_continuity_differentiability_invalid_function_string(self):
        # Test with an invalid function string (non-polynomial)
        with self.assertRaises(ValueError):
            analyze_continuity_differentiability("sin(x)", 0.0)
        with self.assertRaises(ValueError):
            analyze_continuity_differentiability("", 0.0)
        with self.assertRaises(ValueError):
            analyze_continuity_differentiability("x^a", 1.0)

if __name__ == '__main__':
    unittest.main()

