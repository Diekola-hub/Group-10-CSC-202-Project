# tests/test_symbolic_calc.py
# Unit tests for the symbolic_calc module, covering Polynomial class,
# differentiation, integration, limit calculation, and series expansion.

import unittest
import math
import sys # For path manipulation if needed for imports
import os

# Add parent directory to path to allow importing modules from the main project
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from symbolic_calc import Polynomial, differentiate_polynomial, integrate_polynomial, \
                          calculate_limit_lhopital, taylor_maclaurin_series

class TestPolynomial(unittest.TestCase):
    """Tests the Polynomial class for parsing, string conversion, and evaluation."""

    def test_init_valid_polynomials(self):
        # Test various valid polynomial inputs
        p1 = Polynomial("3*x^2 + 2*x - 5")
        self.assertEqual(p1.coefficients, {2: 3.0, 1: 2.0, 0: -5.0})

        p2 = Polynomial("x^3 - x + 1")
        self.assertEqual(p2.coefficients, {3: 1.0, 1: -1.0, 0: 1.0})

        p3 = Polynomial("7")
        self.assertEqual(p3.coefficients, {0: 7.0})

        p4 = Polynomial("-x^2")
        self.assertEqual(p4.coefficients, {2: -1.0})

        p5 = Polynomial("x")
        self.assertEqual(p5.coefficients, {1: 1.0})

        p6 = Polynomial("0")
        self.assertEqual(p6.coefficients, {0: 0.0})

        p7 = Polynomial("2.5*x^1 - 0.5*x^0")
        self.assertEqual(p7.coefficients, {1: 2.5, 0: -0.5})

        p8 = Polynomial("-x^5 + 3*x^2")
        self.assertEqual(p8.coefficients, {5: -1.0, 2: 3.0})

        p9 = Polynomial("4*x^0")
        self.assertEqual(p9.coefficients, {0: 4.0})

        p10 = Polynomial("3*x^2 + 0*x - 5") # Test zero coefficient handling
        self.assertEqual(p10.coefficients, {2: 3.0, 0: -5.0})

    def test_init_invalid_polynomials(self):
        # Test invalid polynomial inputs
        with self.assertRaises(ValueError):
            Polynomial("3x^2") # Missing '*'
        with self.assertRaises(ValueError):
            Polynomial("3*x^a") # Non-integer exponent
        with self.assertRaises(ValueError):
            Polynomial("sin(x)") # Non-polynomial function
        with self.assertRaises(ValueError):
            Polynomial("") # Empty string
        with self.assertRaises(ValueError):
            Polynomial("3*x^2 + invalid_term")

    def test_to_string(self):
        # Test conversion back to string
        self.assertEqual(Polynomial("3*x^2 + 2*x - 5").to_string(), "3.0*x^2 + 2.0*x - 5.0")
        self.assertEqual(Polynomial("x^3 - x + 1").to_string(), "1.0*x^3 - 1.0*x + 1.0")
        self.assertEqual(Polynomial("7").to_string(), "7.0")
        self.assertEqual(Polynomial("-x^2").to_string(), "-1.0*x^2")
        self.assertEqual(Polynomial("x").to_string(), "1.0*x")
        self.assertEqual(Polynomial("0").to_string(), "0")
        self.assertEqual(Polynomial("2.5*x - 0.5").to_string(), "2.5*x - 0.5")
        self.assertEqual(Polynomial("-x^5 + 3*x^2").to_string(), "-1.0*x^5 + 3.0*x^2")
        self.assertEqual(Polynomial("4*x^0").to_string(), "4.0")
        self.assertEqual(Polynomial("3*x^2 + 0*x - 5").to_string(), "3.0*x^2 - 5.0")
        self.assertEqual(Polynomial("1*x^2").to_string(), "1.0*x^2") # Test explicit 1 coeff

    def test_evaluate(self):
        # Test polynomial evaluation
        p1 = Polynomial("x^2 + 2*x - 1")
        self.assertEqual(p1.evaluate(0), -1.0)
        self.assertEqual(p1.evaluate(1), 2.0)
        self.assertEqual(p1.evaluate(-1), -2.0)
        self.assertEqual(p1.evaluate(2), 7.0)

        p2 = Polynomial("5")
        self.assertEqual(p2.evaluate(100), 5.0)

        p3 = Polynomial("x")
        self.assertEqual(p3.evaluate(3), 3.0)

        p4 = Polynomial("0")
        self.assertEqual(p4.evaluate(5), 0.0)


class TestSymbolicCalculus(unittest.TestCase):
    """Tests differentiation, integration, limits, and series expansion functions."""

    def test_differentiate_polynomial(self):
        # Test differentiation
        p1 = Polynomial("x^2 + 2*x - 5")
        d1 = differentiate_polynomial(p1)
        self.assertEqual(d1.to_string(), "2.0*x + 2.0")

        p2 = Polynomial("3*x^3")
        d2 = differentiate_polynomial(p2)
        self.assertEqual(d2.to_string(), "9.0*x^2")

        p3 = Polynomial("7")
        d3 = differentiate_polynomial(p3)
        self.assertEqual(d3.to_string(), "0")

        p4 = Polynomial("x")
        d4 = differentiate_polynomial(p4)
        self.assertEqual(d4.to_string(), "1.0")

        p5 = Polynomial("0")
        d5 = differentiate_polynomial(p5)
        self.assertEqual(d5.to_string(), "0")

        p6 = Polynomial("-4*x^2 + x - 10")
        d6 = differentiate_polynomial(p6)
        self.assertEqual(d6.to_string(), "-8.0*x + 1.0")

    def test_integrate_polynomial(self):
        # Test integration
        p1 = Polynomial("2*x + 2")
        i1 = integrate_polynomial(p1)
        self.assertEqual(i1.to_string(), "1.0*x^2 + 2.0*x") # Note: +C is handled in CLI/report

        p2 = Polynomial("9*x^2")
        i2 = integrate_polynomial(p2)
        self.assertEqual(i2.to_string(), "3.0*x^3")

        p3 = Polynomial("0")
        i3 = integrate_polynomial(p3)
        self.assertEqual(i3.to_string(), "0")

        p4 = Polynomial("1")
        i4 = integrate_polynomial(p4)
        self.assertEqual(i4.to_string(), "1.0*x")

        p5 = Polynomial("x^3 - x + 1")
        i5 = integrate_polynomial(p5)
        self.assertEqual(i5.to_string(), "0.25*x^4 - 0.5*x^2 + 1.0*x")

    def test_calculate_limit_lhopital(self):
        # Test L'Hôpital's Rule
        # 0/0 form: (x^2 - 1) / (x - 1) as x->1 should be 2
        limit, steps = calculate_limit_lhopital("x^2 - 1", "x - 1", 1)
        self.assertAlmostEqual(limit, 2.0)
        self.assertIn("Indeterminate form (0/0 or inf/inf) detected. Applying L'Hôpital's Rule.", steps[1])
        self.assertIn("Derivative of Numerator: 2.0*x", steps[4])
        self.assertIn("Derivative of Denominator: 1.0", steps[5])

        # 0/0 form: (x^3 - 8) / (x - 2) as x->2 should be 12
        limit, steps = calculate_limit_lhopital("x^3 - 8", "x - 2", 2)
        self.assertAlmostEqual(limit, 12.0)

        # Non-indeterminate form: (x^2 + 1) / (x + 1) as x->1 should be 1
        limit, steps = calculate_limit_lhopital("x^2 + 1", "x + 1", 1)
        self.assertAlmostEqual(limit, 1.0)
        self.assertIn("Not an indeterminate form, direct substitution yields a finite value.", steps[0])

        # Non-indeterminate form: (x + 1) / (x - 1) as x->1 should be Infinity
        limit, steps = calculate_limit_lhopital("x + 1", "x - 1", 1)
        self.assertEqual(limit, "Infinity")

        # Constant / 0: (5) / (x - 1) as x->1 should be Infinity
        limit, steps = calculate_limit_lhopital("5", "x - 1", 1)
        self.assertEqual(limit, "Infinity")

        # 0 / non-zero: (x - 1) / (x + 1) as x->1 should be 0
        limit, steps = calculate_limit_lhopital("x - 1", "x + 1", 1)
        self.assertAlmostEqual(limit, 0.0)

        # Inf/Inf form: (2*x^2 + x) / (x^2 + 1) as x->inf should be 2
        limit, steps = calculate_limit_lhopital("2*x^2 + x", "x^2 + 1", float('inf'))
        self.assertAlmostEqual(limit, 2.0)
        self.assertIn("Indeterminate form (0/0 or inf/inf) detected. Applying L'Hôpital's Rule.", steps[1])

        # Inf/Inf form: (x^3) / (x^2) as x->inf should be Infinity
        limit, steps = calculate_limit_lhopital("x^3", "x^2", float('inf'))
        self.assertEqual(limit, "Infinity")

        # 0/0 form requiring multiple applications: (x^2 - 2x + 1) / (x^2 - 1) as x->1 should be 0
        # This is (x-1)^2 / (x-1)(x+1) = (x-1)/(x+1) -> 0/2 = 0
        limit, steps = calculate_limit_lhopital("x^2 - 2*x + 1", "x^2 - 1", 1)
        self.assertAlmostEqual(limit, 0.0)
        self.assertGreater(len(steps), 5) # Should show multiple differentiation steps

        # Test case where denominator derivative becomes zero and numerator is non-zero
        limit, steps = calculate_limit_lhopital("x", "x^2", float('inf'))
        self.assertEqual(limit, 0.0) # (1) / (2x) -> 0 as x->inf

        # Test case where numerator derivative becomes zero and denominator is non-zero
        limit, steps = calculate_limit_lhopital("x^2", "x^3", float('inf'))
        self.assertEqual(limit, 0.0) # (2x) / (3x^2) -> (2) / (6x) -> 0 as x->inf

    def test_taylor_maclaurin_series(self):
        # Test Maclaurin series (center = 0)
        p1 = Polynomial("x^2")
        series, steps = taylor_maclaurin_series(p1, 0, 2)
        self.assertEqual(series, "0.0 + 0.0*x + 1.0*x^2") # Should simplify to "x^2" in a real app, but this is raw output
        # Check for correct coefficients
        self.assertIn("f^(0)(0) = 0.0", steps)
        self.assertIn("f^(1)(0) = 0.0", steps)
        self.assertIn("f^(2)(0) = 2.0", steps)

        p2 = Polynomial("x^3 - 2*x + 1")
        series, steps = taylor_maclaurin_series(p2, 0, 3)
        self.assertEqual(series, "1.0 - 2.0*x + 0.0*x^2 + 1.0*x^3")

        p3 = Polynomial("5")
        series, steps = taylor_maclaurin_series(p3, 0, 5)
        self.assertEqual(series, "5.0")

        # Test Taylor series (center != 0)
        p4 = Polynomial("x^2")
        series, steps = taylor_maclaurin_series(p4, 1, 2) # (x-1)^2 + 2(x-1) + 1 = x^2 - 2x + 1 + 2x - 2 + 1 = x^2
        self.assertEqual(series, "1.0 + 2.0*(x - 1) + 1.0*(x - 1)^2")

        p5 = Polynomial("x^3")
        series, steps = taylor_maclaurin_series(p5, 2, 3) # (x-2)^3 + 6(x-2)^2 + 12(x-2) + 8
        self.assertEqual(series, "8.0 + 12.0*(x - 2) + 6.0*(x - 2)^2 + 1.0*(x - 2)^3")


if __name__ == '__main__':
    unittest.main()

