# tests/test_numerical_solver.py
# Unit tests for the numerical_solver module, covering Euler's method for ODEs.

import unittest
import sys # For path manipulation if needed for imports
import os

# Add parent directory to path to allow importing modules from the main project
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from numerical_solver import solve_ode_euler

class TestNumericalSolver(unittest.TestCase):
    """Tests the numerical ODE solver using Euler's method."""

    def test_solve_ode_euler_simple_constant(self):
        # dy/dx = 2, y(0) = 0. Solution: y = 2x
        # x=0, y=0 -> (0,0)
        # x=0.5, y=1 -> (0.5,1)
        # x=1.0, y=2 -> (1.0,2)
        solution = solve_ode_euler("2", x0=0, y0=0, h=0.5, num_steps=2)
        expected_solution = [(0.0, 0.0), (0.5, 1.0), (1.0, 2.0)]
        
        self.assertEqual(len(solution), len(expected_solution))
        for i in range(len(solution)):
            self.assertAlmostEqual(solution[i][0], expected_solution[i][0])
            self.assertAlmostEqual(solution[i][1], expected_solution[i][1])

    def test_solve_ode_euler_linear(self):
        # dy/dx = x, y(0) = 0. Solution: y = 0.5*x^2
        # x=0, y=0 -> (0,0)
        # x=0.1, y=0 + 0.1*0 = 0 -> (0.1,0)
        # x=0.2, y=0 + 0.1*0.1 = 0.01 -> (0.2,0.01)
        solution = solve_ode_euler("x", x0=0, y0=0, h=0.1, num_steps=2)
        expected_solution = [(0.0, 0.0), (0.1, 0.0), (0.2, 0.01)]

        self.assertEqual(len(solution), len(expected_solution))
        for i in range(len(solution)):
            self.assertAlmostEqual(solution[i][0], expected_solution[i][0], places=5)
            self.assertAlmostEqual(solution[i][1], expected_solution[i][1], places=5)

    def test_solve_ode_euler_quadratic(self):
        # dy/dx = x^2, y(0) = 0. Solution: y = x^3 / 3
        # x=0, y=0 -> (0,0)
        # x=1, y=0 + 1*0^2 = 0 -> (1,0)
        # x=2, y=0 + 1*1^2 = 1 -> (2,1)
        solution = solve_ode_euler("x^2", x0=0, y0=0, h=1, num_steps=2)
        expected_solution = [(0.0, 0.0), (1.0, 0.0), (2.0, 1.0)]

        self.assertEqual(len(solution), len(expected_solution))
        for i in range(len(solution)):
            self.assertAlmostEqual(solution[i][0], expected_solution[i][0], places=5)
            self.assertAlmostEqual(solution[i][1], expected_solution[i][1], places=5)

    def test_solve_ode_euler_with_initial_y(self):
        # dy/dx = 1, y(0) = 5. Solution: y = x + 5
        solution = solve_ode_euler("1", x0=0, y0=5, h=1, num_steps=1)
        expected_solution = [(0.0, 5.0), (1.0, 6.0)]
        
        self.assertEqual(len(solution), len(expected_solution))
        for i in range(len(solution)):
            self.assertAlmostEqual(solution[i][0], expected_solution[i][0], places=5)
            self.assertAlmostEqual(solution[i][1], expected_solution[i][1], places=5)

    def test_solve_ode_euler_negative_h(self):
        # dy/dx = 1, y(0) = 0. h = -0.5, num_steps = 2. Should go backwards
        solution = solve_ode_euler("1", x0=0, y0=0, h=-0.5, num_steps=2)
        expected_solution = [(0.0, 0.0), (-0.5, -0.5), (-1.0, -1.0)]
        
        self.assertEqual(len(solution), len(expected_solution))
        for i in range(len(solution)):
            self.assertAlmostEqual(solution[i][0], expected_solution[i][0], places=5)
            self.assertAlmostEqual(solution[i][1], expected_solution[i][1], places=5)

    def test_solve_ode_euler_invalid_function_string(self):
        # Test with a non-polynomial function string
        with self.assertRaises(ValueError):
            solve_ode_euler("sin(x)", x0=0, y0=0, h=0.1, num_steps=1)
        with self.assertRaises(ValueError):
            solve_ode_euler("", x0=0, y0=0, h=0.1, num_steps=1)
        with self.assertRaises(ValueError):
            solve_ode_euler("x^a", x0=0, y0=0, h=0.1, num_steps=1)

if __name__ == '__main__':
    unittest.main()

