# tests/test_report_gen.py
# Unit tests for the report_gen module, verifying report formatting,
# file creation, and ASCII plotting integration.

import unittest
import os
import shutil
import sys # For path manipulation if needed for imports
from unittest import mock # Import the mock library

# Add parent directory to path to allow importing modules from the main project
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from report_gen import ReportGenerator
from utils import ascii_plotter # To ensure the plotter is mocked correctly

class TestReportGenerator(unittest.TestCase):
    """Tests the ReportGenerator's ability to format and save calculus reports."""

    def setUp(self):
        # Set up a temporary output directory for reports
        self.test_output_dir = "test_reports_temp"
        self.report_generator = ReportGenerator(output_dir=self.test_output_dir)
        os.makedirs(self.test_output_dir, exist_ok=True)

        # Sample data for testing report generation
        self.operation_type = "Symbolic Differentiation"
        self.input_function = "x^2 + 2*x - 5"
        self.result = "The derivative is: 2.0*x + 2.0"
        self.steps = [
            "Input Function: x^2 + 2*x - 5",
            "Applying power rule (d/dx(ax^n) = anx^(n-1)) to each term.",
            "Resulting Derivative: 2.0*x + 2.0"
        ]
        self.plot_data = {
            "original": [(-2, 0), (-1, -2), (0, -1), (1, 2), (2, 7)],
            "derived": [(-2, -2), (-1, 0), (0, 2), (1, 4), (2, 6)]
        }

    def tearDown(self):
        # Clean up the temporary output directory after tests
        if os.path.exists(self.test_output_dir):
            shutil.rmtree(self.test_output_dir)

    def test_generate_report_full_data(self):
        # Test report generation with a complete set of data including steps and plot
        report_path = self.report_generator.generate_report(
            self.operation_type, self.input_function, self.result,
            steps=self.steps, plot_data=self.plot_data, file_name="diff_report.txt"
        )
        self.assertIsNotNone(report_path)
        self.assertTrue(os.path.exists(report_path))

        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()

        self.assertIn("MATHEMATICAL ANALYSIS REPORT - SYMBOLIC DIFFERENTIATION", content)
        self.assertIn(f"Operation Type: {self.operation_type}", content)
        self.assertIn(f"Input Function(s): {self.input_function}", content)
        self.assertIn(f"Result:\n  {self.result}", content)
        self.assertIn("--- Step-by-Step Explanation ---", content)
        self.assertIn("Applying power rule", content)
        self.assertIn("--- ASCII Plot ---", content)
        self.assertIn("Plot for Original:", content)
        self.assertIn("Plot for Derived:", content)
        self.assertIn("END OF REPORT", content)

    def test_generate_report_no_steps_no_plot(self):
        # Test report generation without optional steps or plot data
        report_path = self.report_generator.generate_report(
            "Symbolic Integration", "x^2", "Result: x^3/3 + C",
            steps=None, plot_data=None, file_name="int_report.txt"
        )
        self.assertIsNotNone(report_path)
        self.assertTrue(os.path.exists(report_path))

        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()

        self.assertIn("MATHEMATICAL ANALYSIS REPORT - SYMBOLIC INTEGRATION", content)
        self.assertIn("No detailed steps available for this operation.", content)
        self.assertIn("No plot generated for this operation.", content)

    def test_generate_report_default_file_name(self):
        # Test that a report is generated with a default timestamped file name
        report_path = self.report_generator.generate_report(
            "Calculate Limit", "x/x", "Result: 1.0"
        )
        self.assertIsNotNone(report_path)
        self.assertTrue(os.path.exists(report_path))
        self.assertTrue(os.path.basename(report_path).startswith("calculate_limit_report_"))
        self.assertTrue(os.path.basename(report_path).endswith(".txt"))

    @mock.patch('builtins.open')
    def test_generate_report_io_error(self, mock_open):
        # Test error handling when the report file cannot be written due to an IOError
        mock_open.side_effect = IOError("Simulated permission denied error")

        report_path = self.report_generator.generate_report(
            self.operation_type, self.input_function, self.result, file_name="error_report.txt"
        )
        self.assertIsNone(report_path)
        mock_open.assert_called_once()

    @mock.patch('utils.ascii_plotter') # Mock the ascii_plotter function
    def test_generate_report_with_plot_data_calls_plotter(self, mock_ascii_plotter):
        # Configure mock_ascii_plotter to return dummy lines
        mock_ascii_plotter.return_value = ["dummy plot line 1", "dummy plot line 2"]

        report_path = self.report_generator.generate_report(
            self.operation_type, self.input_function, self.result,
            steps=self.steps, plot_data=self.plot_data, file_name="plot_test_report.txt"
        )
        self.assertIsNotNone(report_path)
        self.assertTrue(os.path.exists(report_path))

        # Assert that ascii_plotter was called for each set of points
        self.assertEqual(mock_ascii_plotter.call_count, 2) # Called for 'original' and 'derived'

        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()
        self.assertIn("dummy plot line 1", content)
        self.assertIn("dummy plot line 2", content)


if __name__ == '__main__':
    unittest.main()

