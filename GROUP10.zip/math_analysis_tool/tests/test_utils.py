# tests/test_utils.py
# Unit tests for the utils module, covering InputValidator and polynomial parsing.

import unittest
import sys # For path manipulation if needed for imports
import os
from unittest import mock # For mocking input

# Add parent directory to path to allow importing modules from the main project
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils import InputValidator, parse_polynomial_string, ascii_plotter

class TestInputValidator(unittest.TestCase):
    """Tests the InputValidator static methods."""

    @mock.patch('builtins.input', side_effect=['5'])
    def test_get_valid_int_input_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_int_input("Enter int: "), 5)

    @mock.patch('builtins.input', side_effect=['abc', '10'])
    def test_get_valid_int_input_invalid_then_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_int_input("Enter int: "), 10)

    @mock.patch('builtins.input', side_effect=['3'])
    def test_get_valid_int_input_min_max_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_int_input("Enter int: ", 1, 5), 3)

    @mock.patch('builtins.input', side_effect=['0', '6', '4'])
    def test_get_valid_int_input_min_max_invalid_then_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_int_input("Enter int: ", 1, 5), 4)

    @mock.patch('builtins.input', side_effect=['3.14'])
    def test_get_valid_float_input_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_float_input("Enter float: "), 3.14)

    @mock.patch('builtins.input', side_effect=['xyz', '2.71'])
    def test_get_valid_float_input_invalid_then_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_float_input("Enter float: "), 2.71)

    @mock.patch('builtins.input', side_effect=['1.0'])
    def test_get_valid_float_input_min_max_valid(self, mock_input):
        self.assertEqual(InputValidator.get_valid_float_input("Enter float: ", 0.5, 1.5), 1.0)

    @mock.patch('builtins.input', side_effect=['no'])
    def test_get_yes_no_input_no(self, mock_input):
        self.assertFalse(InputValidator.get_yes_no_input("Continue?"))

    @mock.patch('builtins.input', side_effect=['YES'])
    def test_get_yes_no_input_yes(self, mock_input):
        self.assertTrue(InputValidator.get_yes_no_input("Continue?"))

    @mock.patch('builtins.input', side_effect=['maybe', 'y'])
    def test_get_yes_no_input_invalid_then_valid(self, mock_input):
        self.assertTrue(InputValidator.get_yes_no_input("Continue?"))


class TestPolynomialParser(unittest.TestCase):
    """Tests the parse_polynomial_string utility function."""

    def test_parse_simple_terms(self):
        self.assertEqual(parse_polynomial_string("3*x^2"), {2: 3.0})
        self.assertEqual(parse_polynomial_string("x^3"), {3: 1.0})
        self.assertEqual(parse_polynomial_string("2*x"), {1: 2.0})
        self.assertEqual(parse_polynomial_string("x"), {1: 1.0})
        self.assertEqual(parse_polynomial_string("5"), {0: 5.0})
        self.assertEqual(parse_polynomial_string("-x"), {1: -1.0})
        self.assertEqual(parse_polynomial_string("-4*x^2"), {2: -4.0})
        self.assertEqual(parse_polynomial_string("0"), {0: 0.0})
        self.assertEqual(parse_polynomial_string("1*x^0"), {0: 1.0})
        self.assertEqual(parse_polynomial_string("1*x"), {1: 1.0})


    def test_parse_multiple_terms(self):
        self.assertEqual(parse_polynomial_string("3*x^2 + 2*x - 5"), {2: 3.0, 1: 2.0, 0: -5.0})
        self.assertEqual(parse_polynomial_string("x^3 - x + 1"), {3: 1.0, 1: -1.0, 0: 1.0})
        self.assertEqual(parse_polynomial_string("-x^2 + 7*x^5 - 10"), {2: -1.0, 5: 7.0, 0: -10.0})
        self.assertEqual(parse_polynomial_string("2*x - 3*x^2 + 1"), {1: 2.0, 2: -3.0, 0: 1.0})
        self.assertEqual(parse_polynomial_string("x^2 + x + 1"), {2: 1.0, 1: 1.0, 0: 1.0})

    def test_parse_with_spaces(self):
        self.assertEqual(parse_polynomial_string("  3 * x ^ 2  +  2 * x  -  5  "), {2: 3.0, 1: 2.0, 0: -5.0})

    def test_parse_float_coefficients(self):
        self.assertEqual(parse_polynomial_string("0.5*x^2 - 1.5*x + 0.25"), {2: 0.5, 1: -1.5, 0: 0.25})

    def test_parse_zero_coefficients(self):
        # Terms with zero coefficients should be handled correctly (not necessarily removed by parser)
        # The Polynomial class __init__ removes them.
        coeffs = parse_polynomial_string("3*x^2 + 0*x - 5")
        self.assertIn(2, coeffs)
        self.assertIn(1, coeffs)
        self.assertIn(0, coeffs)
        self.assertEqual(coeffs[1], 0.0)

    def test_parse_invalid_formats(self):
        with self.assertRaises(ValueError):
            parse_polynomial_string("3x^2") # Missing '*'
        with self.assertRaises(ValueError):
            parse_polynomial_string("x^a") # Non-integer exponent
        with self.assertRaises(ValueError):
            parse_polynomial_string("sin(x)") # Non-polynomial
        with self.assertRaises(ValueError):
            parse_polynomial_string("") # Empty string
        with self.assertRaises(ValueError):
            parse_polynomial_string("3*x^2 + invalid")
        with self.assertRaises(ValueError):
            parse_polynomial_string("x**2") # Invalid exponentiation operator

class TestASCIIPlotter(unittest.TestCase):
    """Tests the ascii_plotter utility function."""

    def test_simple_line(self):
        points = [(0, 0), (1, 1), (2, 2)]
        plot_lines = ascii_plotter(points, 0, 2, 0, 2, width=10, height=5)
        self.assertIsInstance(plot_lines, list)
        self.assertGreater(len(plot_lines), 0)
        # Check if the '*' characters are roughly on the diagonal
        # This is a basic check, exact pixel mapping is hard for ASCII
        self.assertIn("*", plot_lines[4]) # (0,0) -> bottom-left
        self.assertIn("*", plot_lines[3]) # (1,1) -> middle
        self.assertIn("*", plot_lines[2]) # (2,2) -> top-right

    def test_horizontal_line(self):
        points = [(0, 1), (1, 1), (2, 1)]
        plot_lines = ascii_plotter(points, 0, 2, 0, 2, width=10, height=5)
        self.assertIsInstance(plot_lines, list)
        # Check if '*' are on the same y-level (row)
        self.assertIn("*", plot_lines[2]) # Should be on the same row for y=1

    def test_empty_points(self):
        points = []
        plot_lines = ascii_plotter(points, 0, 10, 0, 10, width=10, height=5)
        self.assertIsInstance(plot_lines, list)
        # Should still draw axes
        self.assertIn('|', plot_lines[0])
        self.assertIn('-', plot_lines[4])

    def test_single_point(self):
        points = [(5, 5)]
        plot_lines = ascii_plotter(points, 0, 10, 0, 10, width=10, height=5)
        self.assertIsInstance(plot_lines, list)
        # Check if '*' is present somewhere
        found_star = False
        for line in plot_lines:
            if '*' in line:
                found_star = True
                break
        self.assertTrue(found_star)

    def test_ranges_equal(self):
        # Test case where x_min == x_max or y_min == y_max
        points = [(0,0)]
        plot_lines = ascii_plotter(points, 0, 0, 0, 0, width=10, height=10)
        self.assertIsInstance(plot_lines, list)
        self.assertGreater(len(plot_lines), 0)
        # Should still produce a grid, even if scaled to a single point
        found_star = False
        for line in plot_lines:
            if '*' in line:
                found_star = True
                break
        self.assertTrue(found_star)


if __name__ == '__main__':
    unittest.main()







