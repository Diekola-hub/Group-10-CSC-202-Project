# main.py
# This is the main command-line interface (CLI) application for the Mathematical Analysis Tool.
# It orchestrates user interaction, dispatches to calculus modules, and manages analysis history.

import os
import datetime # For timestamping reports
import sys # For exiting the program cleanly

# Import core modules of the application
from symbolic_calc import Polynomial, differentiate_polynomial, integrate_polynomial, calculate_limit_lhopital, taylor_maclaurin_series
from numerical_solver import solve_ode_euler
from function_analysis import analyze_continuity_differentiability
from report_gen import ReportGenerator
from utils import InputValidator, parse_polynomial_string # Import parse_polynomial_string as a utility

# Initialize ReportGenerator
report_generator = ReportGenerator()

def display_menu():
    """Displays the main menu of the Mathematical Analysis Tool."""
    print("\n" + "="*40)
    print("  MATHEMATICAL ANALYSIS TOOL CLI")
    print("="*40)
    print("1. Symbolic Differentiation")
    print("2. Symbolic Integration")
    print("3. Solve Differential Equation (Numerical)")
    print("4. Calculate Limit")
    print("5. Find Series Expansion")
    print("6. Analyze Function Continuity & Differentiability")
    print("7. View Analysis History")
    print("8. Exit")
    print("="*40)

def run_analysis_option(choice, analysis_history):
    """
    Executes the chosen calculus operation and adds the result to history.

    Args:
        choice (int): The user's menu choice.
        analysis_history (list): A list to store records of performed analyses.
    """
    operation_name = ""
    input_func_str = ""
    result_str = ""
    steps_list = [] # For step-by-step explanations
    plot_points = None # For ASCII plotting

    try:
        if choice == 1: # Symbolic Differentiation
            operation_name = "Symbolic Differentiation"
            print(f"\n--- {operation_name} ---")
            input_func_str = input("Enter a polynomial function (e.g., 3*x^2 + 2*x - 5): ").strip()
            if not input_func_str:
                print("[INFO] Function input cannot be empty. Returning to menu.")
                return

            try:
                func_poly = Polynomial(input_func_str)
                derived_poly = differentiate_polynomial(func_poly)
                result_str = f"The derivative of {func_poly.to_string()} is: {derived_poly.to_string()}"
                steps_list.append(f"Input Function: {func_poly.to_string()}")
                steps_list.append(f"Applying power rule (d/dx(ax^n) = anx^(n-1)) to each term.")
                steps_list.append(f"Resulting Derivative: {derived_poly.to_string()}")

                # Prepare plot data for the original function and its derivative
                plot_points_original = [(x, func_poly.evaluate(x)) for x in range(-5, 6)]
                plot_points_derived = [(x, derived_poly.evaluate(x)) for x in range(-5, 6)]
                plot_points = {"original": plot_points_original, "derived": plot_points_derived}

            except ValueError as e:
                result_str = f"[ERROR] Invalid function input: {e}"
            except Exception as e:
                result_str = f"[ERROR] An unexpected error occurred: {e}"

        elif choice == 2: # Symbolic Integration
            operation_name = "Symbolic Integration"
            print(f"\n--- {operation_name} ---")
            input_func_str = input("Enter a polynomial function (e.g., 3*x^2 + 2*x - 5): ").strip()
            if not input_func_str:
                print("[INFO] Function input cannot be empty. Returning to menu.")
                return

            try:
                func_poly = Polynomial(input_func_str)
                integrated_poly = integrate_polynomial(func_poly)
                result_str = f"The indefinite integral of {func_poly.to_string()} is: {integrated_poly.to_string()} + C"
                steps_list.append(f"Input Function: {func_poly.to_string()}")
                steps_list.append(f"Applying power rule (∫ax^n dx = (a/(n+1))x^(n+1)) to each term.")
                steps_list.append(f"Resulting Integral: {integrated_poly.to_string()} + C")

                # Prepare plot data for the original function and its integral
                plot_points_original = [(x, func_poly.evaluate(x)) for x in range(-5, 6)]
                plot_points_integrated = [(x, integrated_poly.evaluate(x)) for x in range(-5, 6)]
                plot_points = {"original": plot_points_original, "integrated": plot_points_integrated}

            except ValueError as e:
                result_str = f"[ERROR] Invalid function input: {e}"
            except Exception as e:
                result_str = f"[ERROR] An unexpected error occurred: {e}"

        elif choice == 3: # Solve Differential Equation (Numerical)
            operation_name = "Solve Differential Equation (Numerical)"
            print(f"\n--- {operation_name} ---")
            input_func_str = input("Enter f(x) for dy/dx = f(x) (e.g., x^2 - 2*x): ").strip()
            if not input_func_str:
                print("[INFO] Function input cannot be empty. Returning to menu.")
                return

            try:
                x0 = InputValidator.get_valid_float_input("Enter initial x0: ")
                y0 = InputValidator.get_valid_float_input("Enter initial y0: ")
                h = InputValidator.get_valid_float_input("Enter step size (h): ")
                num_steps = InputValidator.get_valid_int_input("Enter number of steps: ", min_val=1)

                solution_points = solve_ode_euler(input_func_str, x0, y0, h, num_steps)
                result_str = "Numerical Solution Points (x, y):\n" + \
                             "\n".join([f"  ({p[0]:.4f}, {p[1]:.4f})" for p in solution_points])

                steps_list.append(f"Equation: dy/dx = {input_func_str}")
                steps_list.append(f"Initial conditions: x0={x0}, y0={y0}")
                steps_list.append(f"Method: Euler's Method (y_n+1 = y_n + h * f(x_n, y_n))")
                steps_list.append(f"Step size (h): {h}, Number of steps: {num_steps}")
                steps_list.append("Approximated Solution Points:")
                steps_list.extend([f"  ({p[0]:.4f}, {p[1]:.4f})" for p in solution_points])

                # Prepare plot data for the numerical solution
                plot_points = {"solution": solution_points}

            except ValueError as e:
                result_str = f"[ERROR] Invalid input: {e}"
            except Exception as e:
                result_str = f"[ERROR] An unexpected error occurred: {e}"

        elif choice == 4: # Calculate Limit
            operation_name = "Calculate Limit"
            print(f"\n--- {operation_name} ---")
            numerator_str = input("Enter numerator function (e.g., x^2 - 1): ").strip()
            denominator_str = input("Enter denominator function (e.g., x - 1): ").strip()
            if not numerator_str or not denominator_str:
                print("[INFO] Both numerator and denominator functions are required. Returning to menu.")
                return

            point_str = input("Enter point 'a' (e.g., 1, or 'inf' for infinity): ").strip().lower()
            if not point_str:
                print("[INFO] Limit point cannot be empty. Returning to menu.")
                return

            point = None
            if point_str == 'inf':
                point = float('inf')
            else:
                try:
                    point = float(point_str)
                except ValueError:
                    result_str = "[ERROR] Invalid point input. Please enter a number or 'inf'."
                    print(result_str)
                    return

            try:
                limit_val, steps = calculate_limit_lhopital(numerator_str, denominator_str, point)
                result_str = f"The limit of ({numerator_str}) / ({denominator_str}) as x approaches {point_str} is: {limit_val}"
                steps_list.append(f"Function: f(x) = ({numerator_str}) / ({denominator_str})")
                steps_list.append(f"As x approaches: {point_str}")
                steps_list.append("L'Hôpital's Rule Application:")
                steps_list.extend(steps) # Add steps from the function
                steps_list.append(f"Final Limit: {limit_val}")

            except ValueError as e:
                result_str = f"[ERROR] Invalid function input or point: {e}"
            except Exception as e:
                result_str = f"[ERROR] An unexpected error occurred: {e}"

        elif choice == 5: # Find Series Expansion
            operation_name = "Find Series Expansion"
            print(f"\n--- {operation_name} ---")
            input_func_str = input("Enter a polynomial function (e.g., x^3 - 2*x + 1): ").strip()
            if not input_func_str:
                print("[INFO] Function input cannot be empty. Returning to menu.")
                return

            try:
                center = InputValidator.get_valid_float_input("Enter center point 'a' (0 for Maclaurin series): ")
                order = InputValidator.get_valid_int_input("Enter order 'n' of expansion: ", min_val=0)

                func_poly = Polynomial(input_func_str)
                series_expansion, expansion_steps = taylor_maclaurin_series(func_poly, center, order)
                series_type = "Maclaurin" if center == 0 else "Taylor"
                result_str = f"The {series_type} series expansion of {func_poly.to_string()} around x={center} up to order {order} is:\n{series_expansion}"

                steps_list.append(f"Function: {func_poly.to_string()}")
                steps_list.append(f"Center (a): {center}, Order (n): {order}")
                steps_list.append(f"Type: {series_type} Series")
                steps_list.append("Steps:")
                steps_list.extend(expansion_steps)
                steps_list.append(f"Final Series Expansion:\n{series_expansion}")

                # Prepare plot data for the original function and its series approximation
                plot_points_original = [(x, func_poly.evaluate(x)) for x in range(int(center)-5, int(center)+6)]
                # Create a polynomial object from the series expansion string to plot it
                try:
                    series_poly = Polynomial(series_expansion)
                    plot_points_series = [(x, series_poly.evaluate(x)) for x in range(int(center)-5, int(center)+6)]
                    plot_points = {"original": plot_points_original, "series": plot_points_series}
                except ValueError:
                    print("[WARNING] Could not plot series expansion due to parsing error.")
                    plot_points = {"original": plot_points_original} # Plot only original if series fails to parse

            except ValueError as e:
                result_str = f"[ERROR] Invalid input: {e}"
            except Exception as e:
                result_str = f"[ERROR] An unexpected error occurred: {e}"

        elif choice == 6: # Analyze Function Continuity & Differentiability
            operation_name = "Analyze Function Continuity & Differentiability"
            print(f"\n--- {operation_name} ---")
            input_func_str = input("Enter a polynomial function (e.g., x^2 + 5): ").strip()
            if not input_func_str:
                print("[INFO] Function input cannot be empty. Returning to menu.")
                return

            try:
                point = InputValidator.get_valid_float_input("Enter point x0 to analyze at: ")
                analysis_result, analysis_steps = analyze_continuity_differentiability(input_func_str, point)
                result_str = analysis_result

                steps_list.append(f"Function: {input_func_str}")
                steps_list.append(f"Analysis Point (x0): {point}")
                steps_list.extend(analysis_steps)

                # Prepare plot data for the function
                func_poly = Polynomial(input_func_str)
                plot_points_func = [(x, func_poly.evaluate(x)) for x in range(int(point)-5, int(point)+6)]
                plot_points = {"function": plot_points_func}

            except ValueError as e:
                result_str = f"[ERROR] Invalid input: {e}"
            except Exception as e:
                result_str = f"[ERROR] An unexpected error occurred: {e}"

        elif choice == 7: # View Analysis History
            operation_name = "View Analysis History"
            print(f"\n--- {operation_name} ---")
            if not analysis_history:
                print("No analysis history available yet.")
                return

            for i, record in enumerate(analysis_history):
                print(f"\n--- Record {i+1} ---")
                print(f"Operation: {record['operation']}")
                print(f"Input: {record['input']}")
                print(f"Result:\n{record['result']}")
                if record['report_path']:
                    print(f"Report saved to: {record['report_path']}")
                print("-" * 20)

            if InputValidator.get_yes_no_input("Do you want to save the current history to a file (history.txt)?"):
                try:
                    with open("history.txt", "a", encoding="utf-8") as f:
                        f.write(f"\n--- Session History ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ---\n")
                        for record in analysis_history:
                            f.write(f"Operation: {record['operation']}\n")
                            f.write(f"Input: {record['input']}\n")
                            f.write(f"Result:\n{record['result']}\n")
                            if record['report_path']:
                                f.write(f"Report Path: {record['report_path']}\n")
                            f.write("-" * 20 + "\n")
                    print("[SUCCESS] History saved to history.txt")
                except IOError as e:
                    print(f"[ERROR] Could not save history: {e}")
                except Exception as e:
                    print(f"[ERROR] An unexpected error occurred while saving history: {e}")

            input("\nPress Enter to continue...")
            return # Don't generate a report for history view itself

        # If an operation was performed (choices 1-6), generate and save a report
        if operation_name and result_str:
            print(f"\n{result_str}") # Display result to console immediately
            report_path = report_generator.generate_report(
                operation_name, input_func_str, result_str, steps=steps_list, plot_data=plot_points
            )
            analysis_history.append({
                "operation": operation_name,
                "input": input_func_str,
                "result": result_str,
                "report_path": report_path
            })
            if report_path:
                print(f"[INFO] Detailed report saved to: {report_path}")

    except Exception as e:
        print(f"[CRITICAL ERROR] An unhandled error occurred during operation: {e}")
        import traceback
        traceback.print_exc() # Print full traceback for debugging
    finally:
        input("\nPress Enter to continue...")


def main():
    """Main function to run the CLI application loop."""
    analysis_history = [] # Stores history for the current session

    while True:
        display_menu()
        choice = InputValidator.get_valid_int_input("Enter your choice: ", 1, 8)

        if choice == 8:
            print("Exiting Mathematical Analysis Tool. Goodbye!")
            sys.exit(0) # Exit cleanly
        else:
            run_analysis_option(choice, analysis_history)

if __name__ == "__main__":
    # Ensure 'reports' directory exists at startup
    os.makedirs("reports", exist_ok=True)
    main()
